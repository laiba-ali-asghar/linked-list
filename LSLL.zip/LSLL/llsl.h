#ifndef laiba_list_09
#define laiba_list_09

#include <iostream>
#include <stdexcept>
using namespace std;
template <class T>
class Node
{
public:
    T info;
    Node<T> *next;
    Node();
    Node(T val);
};
template <class T>
class LSLL
{
private:
    Node<T> *head;

public:
    LSLL();
    // Insertion functions
    void insertAtHead(T val);
    void insertAtTail(T val);
    void insertBefore(T key, T val);
    void insertAfter(T key, T val);
    // Deletion functions
    void removeAtHead();
    void removeAtTail();
    void remove(T val);
    void removeBefore(T val);
    void removeAfter(T val);
    // Utility functions
    bool search(T key);
    void update(T key, T val);
    int countNodes();
    void display();
    ~LSLL(); // Destructor
};
template <class T>
Node<T>::Node()
{
    info = 0;
    next = NULL;
}
template <class T>
Node<T>::Node(T val)
{
    info = val;
    next = NULL;
}

template <class T>
void LSLL<T>::insertAtHead(T val)
{
    Node<T> *newNode = new Node<T>(val);
    if (head == Node)
    {
        head = newNode;
    }
    else
    {
        newNode->next = head;
        head = newNode;
    }
}
template <class T>
void LSLL<T>::insertAtTail(T val)
{
    Node<T> *temp = head;
    while (temp != NULL)
    {
        temp = temp->next;
    }
    Node<T> *newNode = new Node<T>(val);
    temp->next = newNode;
}

template <class T>
void LSLL<T>::insertBefore(T key, T val)
{
    if (head == nullptr)
        return; // empty list

    // If head contains the key, insert new node before head
    if (head->info == key)
    {
        Node<T> *newNode = new Node<T>(val);
        newNode->next = head;
        head = newNode;
        return;
    }

    Node<T> *prev = nullptr;
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        if (temp->info == key)
        {
            Node<T> *newNode = new Node<T>(val);
            // prev is guaranteed not-null here because head was checked above
            prev->next = newNode;
            newNode->next = temp;
            return; // inserted, done
        }
        prev = temp;
        temp = temp->next;
    }
}
template <class T>
void LSLL<T>::insertAfter(T key, T val)
{
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        if (temp->info == key)
        {
            Node<T> *newNode = new Node<T>(val);
            newNode->next = temp->next;
            temp->next = newNode;
            return;
        }
        temp = temp->next;
    }
    // If we reach here, no matching key was found
    throw std::runtime_error("insertAfter: no key matched");
}
template <class T>
int LSLL<T>::countNodes()
{
    int count = 0;
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        count++;
        temp = temp->next;
    }
    return count;
}
template <class T>
void LSLL<T>::display()
{
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        cout << temp->info << " ";
        temp = temp->next;
    }
    cout << '\n';
}
template <class T>
bool LSLL<T>::search(T key)
{
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        if (temp->info == key)
        {
            return true;
        }
        temp = temp->next;
    }
    return false;
}
template <class T>
void LSLL<T>::update(T key, T val)
{
    Node<T> *temp = head;
    while (temp != nullptr)
    {
        if (temp->info == key)
        {
            temp->info = val;
            return;
        }
        temp = temp->next;
    }
}
template <class T>
void LSLL<T>::removeAtHead()
{
    if (head == nullptr) return;
    Node<T>* old = head;
    head = head->next;
    delete old;

}
template <class T>
void LSLL<T>::removeAtTail()
{
    if (head == nullptr) return; // empty list

    // single node
    if (head->next == nullptr) {
        delete head;
        head = nullptr;
        return;
    }

    Node<T>* prev = nullptr;
    Node<T>* temp = head;
    while (temp->next != nullptr)
    {
        prev = temp;
        temp = temp->next;
    }
    // temp is tail, prev is node before tail
    prev->next = nullptr;
    delete temp;
}
template <class T>
void LSLL<T>:: remove(T val)
{
    if (head == nullptr) return;

    // If head holds the value, remove it
    if (head->info == val) {
        Node<T>* old = head;
        head = head->next;
        delete old;
        return;
    }

    Node<T>* prev = head;
    Node<T>* temp = head->next;
    while (temp != nullptr)
    {
        if (temp->info == val)
        {
            prev->next = temp->next;
            delete temp;
            return;
        }
        prev = temp;
        temp = temp->next;
    }
}
template <class T>
void LSLL<T>::removeBefore(T val)
{
    if (head == nullptr || head->next == nullptr) return; // empty or single node

    // If the second node holds val, remove head
    if (head->next->info == val) {
        Node<T>* old = head;
        head = head->next;
        delete old;
        return;
    }

    Node<T>* prev = head;
    Node<T>* curr = head->next;
    while (curr->next != nullptr) {
        if (curr->next->info == val) {
            // remove curr
            prev->next = curr->next;
            delete curr;
            return;
        }
        prev = curr;
        curr = curr->next;
    }
}
template <class T>
void LSLL<T>::removeAfter(T val)
{
    if (head == nullptr) return;

    Node<T>* temp = head;
    while (temp != nullptr) {
        if (temp->info == val) {
            Node<T>* toRemove = temp->next;
            if (toRemove == nullptr) return; // nothing after
            temp->next = toRemove->next;
            delete toRemove;
            return;
        }
        temp = temp->next;
    }
}
#endif